LA FERME DU PARC MAXIMILIEN — LOGOPAKKET / KIT LOGO / LOGO KIT
================================================================

NL  Gebruik het logo altijd ongewijzigd, met voldoende vrije ruimte rondom.
    Nooit uitrekken, draaien, hertekenen of van een schaduw voorzien.
FR  Utilisez toujours le logo tel quel, avec une zone de protection suffisante.
    Ne pas l'étirer, le pivoter, le redessiner ni lui ajouter d'ombre.
EN  Always use the logo unmodified, with enough clear space around it.
    Never stretch, rotate, redraw or add a shadow.

Bestanden / Fichiers / Files
  svg/   vector (schaalbaar, drukwerk) — terracotta, bosgroen, zwart, wit
  png/   250 / 500 / 1000 px, transparante achtergrond
  jpg/   op crème en op bosgroen, social avatar 1000×1000
  og/    link-preview 1200×630

Kleuren / Couleurs / Colours
  Bosgroen   #1D3528
  Terracotta #C15C3A
  Crème      #F7F3EB
  Salie      #9CB29B

Pers / Presse / Press: contact@maximilien.site · +32 2 201 56 09
https://maximilien.site/nl/pers
